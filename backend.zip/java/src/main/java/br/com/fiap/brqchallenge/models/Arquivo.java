package br.com.fiap.brqchallenge.models;

public class Arquivo extends AbstractModel {
    public String dsArquivo;
    public String dsTamanhoArquivo;
    public String tpArquivo;
    public byte[] binArquivo;
}
