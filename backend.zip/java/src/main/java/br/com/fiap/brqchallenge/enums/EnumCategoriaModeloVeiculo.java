package br.com.fiap.brqchallenge.enums;

public enum EnumCategoriaModeloVeiculo {
    HATCHBACK,
    FASTBACK,
    SEDAN,
    CUPE,
    SUV,
    CROSSOVER,
    UTILITARIO,
    CONVERSIVEL,
    ESPORTIVO;
}
