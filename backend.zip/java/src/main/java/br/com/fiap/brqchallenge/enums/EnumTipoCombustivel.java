package br.com.fiap.brqchallenge.enums;

public enum EnumTipoCombustivel {
    GASOLINA,
    ETANOL,
    FLEX,
    ELETRICO,
    HIBRIDO;
}
