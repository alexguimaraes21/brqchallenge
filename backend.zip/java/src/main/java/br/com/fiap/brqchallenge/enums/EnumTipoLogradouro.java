package br.com.fiap.brqchallenge.enums;

public enum EnumTipoLogradouro {
    RUA,
    AVENIDA,
    PRACA,
    TRAVESSA,
    RODOVIA;
}
