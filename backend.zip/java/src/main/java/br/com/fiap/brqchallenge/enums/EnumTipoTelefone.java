package br.com.fiap.brqchallenge.enums;

public enum EnumTipoTelefone {
    FIXO,
    CELULAR,
    COMERCIAL;
}
