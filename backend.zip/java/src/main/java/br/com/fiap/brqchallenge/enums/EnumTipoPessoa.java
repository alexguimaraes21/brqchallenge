package br.com.fiap.brqchallenge.enums;

public enum EnumTipoPessoa {
	PF,
	PJ;
}
