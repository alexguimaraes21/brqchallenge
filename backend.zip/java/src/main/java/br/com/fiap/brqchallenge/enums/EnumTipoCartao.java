package br.com.fiap.brqchallenge.enums;

public enum EnumTipoCartao {
    DEBITO,
    CREDITO;
}
